import 'package:flutter/material.dart';
import 'cart.dart';
import 'profile.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    HomeScreenPage(),
    CartScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
   return Scaffold(
  appBar: AppBar(
    title: Text('Hayat Food Delivery'),
  ),
  body: _screens[_currentIndex],
  bottomNavigationBar: BottomNavigationBar(
    backgroundColor: Colors.red, // Set the background color to red
    currentIndex: _currentIndex,
    onTap: (index) {
      setState(() {
        _currentIndex = index;
      });
    },
    selectedItemColor: Colors.white, // Set the color of the selected icon to black
    unselectedItemColor: Colors.black, // Set the color of the unselected icons to black
    items: [
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        label: 'Home',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.shopping_cart),
        label: 'Cart',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.person),
        label: 'Profile',
      ),
    ],
  ),
);

  }
}

class HomeScreenPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 400),
          child: ListView.builder(
            itemCount: _articles.length,
            itemBuilder: (BuildContext context, int index) {
              final item = _articles[index];
              return Container(
                height: 136,
                margin:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8.0),
                decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFFE0E0E0)),
                    borderRadius: BorderRadius.circular(8.0)),
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                        child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.title,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Text("${item.author} · ${item.postedOn}",
                            style: Theme.of(context).textTheme.caption),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icons.bookmark_border_rounded,
                            Icons.share,
                            Icons.more_vert
                          ].map((e) {
                            return InkWell(
                              onTap: () {},
                              child: Padding(
                                padding: const EdgeInsets.only(right: 8.0),
                                child: Icon(e, size: 16),
                              ),
                            );
                          }).toList(),
                        )
                      ],
                    )),
                    Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(8.0),
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage(item.imageUrl),
                            ))),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class Article {
  final String title;
  final String imageUrl;
  final String author;
  final String postedOn;

  Article(
      {required this.title,
      required this.imageUrl,
      required this.author,
      required this.postedOn});
}

final List<Article> _articles = [
  Article(
    title: "Delicious Pizza Recipe",
    author: "Food Network",
    imageUrl: "https://source.unsplash.com/960x540/?pizza",
    postedOn: "Yesterday",
  ),
  Article(
      title: "5 Mouth-Watering Burger Recipes",
      imageUrl: " https://source.unsplash.com/960x540/?burger",
      author: "Epicurious",
      postedOn: "4 hours ago"),
  Article(
    title: "Tasty Pasta Dishes for Dinner",
    author: "New York Times",
    imageUrl: "https://source.unsplash.com/960x540/?pasta",
    postedOn: "2 days ago",
  ),
  Article(
    title: "Authentic Sushi Making Tutorial",
    author: "Food & Wine",
    imageUrl: "https://source.unsplash.com/960x540/?salad",
    postedOn: "22 hours ago",
  ),
  Article(
    title: "Exquisite Desserts for Sweet Tooths",
    author: "Tasty",
    imageUrl: "https://source.unsplash.com/960x540/?sushi",
    postedOn: "2 hours ago",
  ),
  Article(
    title: "Top 10 Indian Curry Recipes",
    author: "BBC Good Food",
    imageUrl: "https://source.unsplash.com/960x540/?dessert",
    postedOn: "10 days ago",
  ),
  Article(
    title: "Amazing Salad Combinations for Summer",
    author: "Cooking Light",
    imageUrl: "https://source.unsplash.com/960x540/?curry",
    postedOn: "10 hours ago",
  ),
];