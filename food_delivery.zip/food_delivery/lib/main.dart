import 'package:flutter/material.dart';
import 'package:food_delivery/login.dart';
import 'package:food_delivery/restaurant_listings.dart';
import 'package:food_delivery/cart.dart';
import 'package:food_delivery/checkout.dart';
import 'package:food_delivery/order_tarcking.dart';
import 'package:food_delivery/profile.dart';
import 'package:food_delivery/restaurant_detail.dart';
import 'package:food_delivery/home.dart';
import 'package:food_delivery/signup.dart';




void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      initialRoute: '/',
      routes: {
        '/': (context) => SignInPage1(),
        '/login': (context) => LoginScreen(),
        '/restaurant_listings': (context) => RestaurantListingsScreen(),
      
        '/cart': (context) => CartScreen(),
        '/checkout': (context) =>CheckoutScreen(),
        '/order_tarcking': (context) => OrderTrackingScreen(),
        '/profile': (context) => ProfileScreen(),
        '/home': (context) => HomeScreen(),
        '/signup': (context) => SignUpScreen(),


        '/restaurant_detail': (context) => RestaurantDetailsScreen(),
},
    );
  }
}

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Screen'),
      ),
      body:
       Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pushNamed(context, '/login');
          },
          child: Text('Go to Login Screen'),
        ),
      ),
    );
  }
}

class SignInPage1 extends StatefulWidget {
  const SignInPage1({Key? key}) : super(key: key);

  @override
  State<SignInPage1> createState() => _SignInPage1State();
}

class _SignInPage1State extends State<SignInPage1> {
  bool _isPasswordVisible = false;
  bool _rememberMe = false;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _formKey,
        child: Center(
          child: Card(
            elevation: 8,
            child: Container(
              padding: const EdgeInsets.all(32.0),
              constraints: const BoxConstraints(maxWidth: 350),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
Image.asset(
              'assets/logofood.png', // Replace 'assets/logo.png' with your image file path
              width: 200,
              height: 200,
            ),                    _gap(),

                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Text(
                        "Welcome To Food Delivery!",
                        style: Theme.of(context).textTheme.headline5,
                      ),
                    ),

                    
                   
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4)),
                        ),
                        child: ElevatedButton(
                                      onPressed: () {
                                         Navigator.pushNamed(context, '/login');
                                         },
                          child: Text(
                            
                            'START',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          
                        ),
                        onPressed: () {
                          if (_formKey.currentState?.validate() ?? false) {
                            /// do something
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _gap() => const SizedBox(height: 16);
}

