import 'package:flutter/material.dart';

class RestaurantDetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Restaurant Details'),
      ),
      body: Center(
        child: Text('Restaurant Details Goes Here'),
      ),
    );
  }
}
