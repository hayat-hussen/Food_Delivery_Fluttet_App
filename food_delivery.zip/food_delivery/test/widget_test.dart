// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:food_delivery/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:food_delivery/login.dart';
import 'package:food_delivery/cart.dart';
import 'package:food_delivery/checkout.dart';
import 'package:food_delivery/order_tarcking.dart';
import 'package:food_delivery/restaurant_detail.dart';
import 'package:food_delivery/profile.dart';

void main() {
  testWidgets('Navigation test', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    // Verify that we're on the main screen initially.
    expect(find.text('Main Screen'), findsOneWidget);

    // Tap the button to navigate to the login screen.
    await tester.tap(find.text('Go to Login Screen'));
    await tester.pumpAndSettle();
    expect(find.text('Login Screen'), findsOneWidget);

    // Tap the button to navigate to the cart screen.
    await tester.tap(find.text('Go to Cart'));
    await tester.pumpAndSettle();
    expect(find.text('Cart'), findsOneWidget);

    // Tap the button to navigate to the checkout screen.
    await tester.tap(find.text('Go to Checkout'));
    await tester.pumpAndSettle();
    expect(find.text('Checkout'), findsOneWidget);

    // Tap the button to navigate to the order tracking screen.
    await tester.tap(find.text('Go to Order Tracking'));
    await tester.pumpAndSettle();
    expect(find.text('Order Tracking'), findsOneWidget);

    // Tap the button to navigate to the restaurant details screen.
    await tester.tap(find.text('Go to Restaurant Details'));
    await tester.pumpAndSettle();
    expect(find.text('Restaurant Details'), findsOneWidget);

    // Tap the button to navigate to the profile screen.
    await tester.tap(find.text('Go to Profile'));
    await tester.pumpAndSettle();
    expect(find.text('Profile'), findsOneWidget);
  });
}
